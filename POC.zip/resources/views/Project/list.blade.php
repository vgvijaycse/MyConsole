@extends('layouts.project')
@if (isset($_GET['q']))
@section('PageTitle', 'Search key :' .$_GET['q'] )
@else
@section('PageTitle', '')
@endif

<script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-5b3609106100445e"></script>
@section('content')

<div class="container projectGrid">
    <h3> Project List</h3>

    <div class="row">
@foreach($data as $data)
   <div class="card col-md-4">
       <a  href="{{ URL::to('project/' . $data->id) }}">
    <div class="project_image">
     <img src="images/{{$data->project_image}}" class="img-responsive">
     </div>
  <div class="card-body">
    <h5 class="card-title">{{$data->project_name}}</h5>
    <p class="card-text">{{$data->project_subject}}</p>
  
  </div>
</a>
</div>
@endforeach  

</div>
</div>
@endsection
