@extends('layouts.project')
<script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-5b3609106100445e"></script>
<script id="dsq-count-scr" src="//myconsole.disqus.com/count.js" async></script>
@section('content')
@foreach($dataArray as $data)
@section('PageTitle', $data->project_name)
<div class="container-fluid project-header">
 <div class="container">
    <div class="row">
      <div class="col-lg-8">
      <div class="clp-lead">
      <div class="clp-component-render">

    <h1 class="clp-lead__title" data-purpose="lead-title">
    {{$data->project_name}}
    </h1>

    <div class="clp-lead__headline" data-purpose="lead-headline">
       <p>   {{$data->project_subject}} </p>
    </div>
   
    <div class="col-md-12 m-t-10">
    <ol class="breadcrumb">
        <li>Created by: {{$data->name}}</li> 
       
        <li>Created at: {{Carbon\Carbon::parse($data->created_at)->format('d-m-Y')}}</li>
        <li>Updated at: {{Carbon\Carbon::parse($data->updated_at)->format('d-m-Y')}}</li>
		
    </ol>
 
    </div>

    </div>
     </div>
    </div>
    <div class="col-lg-4">
    <button class="btn btn-primary m-r-10"> Project Demo</button> 
    <a herf="{{$data->project_github_url}}" class="btn btn-primary"> Browse on GitHub </a>    
    <p><div class="addthis_inline_share_toolbox"></div> </p>
    </div>
  </div>
</div>
</div>
<div style="clear-fix"></div>
<div class="container">
<div class="row">
    <div class="col-md-8">
       <div class="row">
           <div class="pageBox">
               <h3>Project Details</h3>

                 {!!html_entity_decode($data->project_description)!!}
           </div>
       </div>
    </div>
    <div class="col-md-4">
        <div class="right-col__content">
        <div class="right-col__module">
            <div class="project_image">
                <img src="../images/{{$data->project_image}}" class="img-responsive">
            </div>
         </div>
        </div>
    </div>
<div class="row">
<div class="col-md-8"><br>
    <div id="disqus_thread"></div>
</div>
</div>
</div>
</div>
@endforeach  
<script>

/**
*  RECOMMENDED CONFIGURATION VARIABLES: EDIT AND UNCOMMENT THE SECTION BELOW TO INSERT DYNAMIC VALUES FROM YOUR PLATFORM OR CMS.
*  LEARN WHY DEFINING THESE VARIABLES IS IMPORTANT: https://disqus.com/admin/universalcode/#configuration-variables*/
/*
var disqus_config = function () {
this.page.url = PAGE_URL;  // Replace PAGE_URL with your page's canonical URL variable
this.page.identifier = PAGE_IDENTIFIER; // Replace PAGE_IDENTIFIER with your page's unique identifier variable
};
*/
(function() { // DON'T EDIT BELOW THIS LINE
var d = document, s = d.createElement('script');
s.src = 'https://myconsole.disqus.com/embed.js';
s.setAttribute('data-timestamp', +new Date());
(d.head || d.body).appendChild(s);
})();
</script>
<noscript>Please enable JavaScript to view the <a href="https://disqus.com/?ref_noscript">comments powered by Disqus.</a></noscript>
@endsection
