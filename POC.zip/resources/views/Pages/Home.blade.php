@extends('layouts.app')

@section('title', 'Login')

@section('content')
    <p>This is my body content.</p>
@endsection
