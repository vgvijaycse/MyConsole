@extends('layouts.app')

@section('title', 'Login')

@section('content')
<div class="container">

        <nav class="navbar navbar-inverse inner-navbar">
            <div class="navbar-header">
                <a class="navbar-brand" href="{{ URL::to('post') }}">Project</a>
            </div>
            <ul class="nav navbar-nav">
                <li><a href="{{ URL::to('post') }}">View All Project</a></li>
                <li><a href="{{ URL::to('post/create') }}">Create a Project</a>
            </ul>
        </nav>

        <h1>All the Projects</h1>

        <?php //echo $grid ?>

        </div>
@endsection
