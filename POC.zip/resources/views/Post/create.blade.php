@extends('layouts.app')

@section('PageTitle', 'Create Project')

@section('content')<!-- include summernote css/js-->

@include('includes.subnav')
<div class="row">
<div class="col-md-8">

<h3>Create Project</h3>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
            <fieldset class="box h-100 center-block">
<!-- if there are creation errors, they will show here -->
{{ HTML::ul($errors->all()) }}

{{ Form::open(array('url' => 'post','files' => true)) }}

    <div class="form-group">
        {{ Form::label('project_name', 'Project Title') }}
        {{ Form::text('project_name', Input::old('project_name'), array('class' => 'form-control')) }}
    </div>

    <div class="form-group">
        {{ Form::label('project_subject', 'Subject') }}
        {{ Form::text('project_subject', Input::old('project_subject'), array('class' => 'form-control')) }}
    </div>
    <div class="form-group">
            {{ Form::label('project_description', 'Description') }}
            {{ Form::textarea('project_description', Input::old('project_description'), array('class' => 'form-control summernote')) }}
    </div>

    <div class="form-group">
            {{ Form::label('project_github_url', 'Github URL') }}
            {{ Form::text('project_github_url', Input::old('project_github_url'), array('class' => 'form-control')) }}
        </div>
    <div class="form-group">
    {!! Form::label('Image') !!}
    {!! Form::file('project_image', null) !!}
   </div>

    {{ Form::submit('Create the post!', array('class' => 'btn btn-primary')) }}

{{ Form::close() }}

</div>
</div>
</fieldset> 
</div>
</div>
</div>
</div>
<script>
        $(document).ready(function() {
            $('.summernote').summernote(
                {
                height: 200,                 // set editor height
                minHeight: null,             // set minimum height of editor
                maxHeight: null,             // set maximum height of editor                // set focus to editable area after initializing summernote
                }
            );
        });
</script>

@endsection
