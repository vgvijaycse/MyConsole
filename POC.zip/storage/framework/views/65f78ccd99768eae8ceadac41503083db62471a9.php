<?php $__env->startSection('title', 'Login'); ?>

<?php $__env->startSection('content'); ?><!-- include summernote css/js-->


<div class="row">
        <div class="col-md-8">
<h1>Create Post</h1>

<!-- if there are creation errors, they will show here -->
<?php echo e(HTML::ul($errors->all())); ?>


<?php echo e(Form::open(array('url' => 'post'))); ?>


    <div class="form-group">
        <?php echo e(Form::label('project_name', 'Project Title')); ?>

        <?php echo e(Form::text('project_name', Input::old('project_name'), array('class' => 'form-control'))); ?>

    </div>

    <div class="form-group">
        <?php echo e(Form::label('project_subject', 'Subject')); ?>

        <?php echo e(Form::text('project_subject', Input::old('project_subject'), array('class' => 'form-control'))); ?>

    </div>
    <div class="form-group">
            <?php echo e(Form::label('project_description', 'Description')); ?>

            <?php echo e(Form::textarea('project_description', Input::old('project_description'), array('class' => 'form-control summernote'))); ?>

    </div>

    <div class="form-group">
            <?php echo e(Form::label('project_github_url', 'Github URL')); ?>

            <?php echo e(Form::text('project_github_url', Input::old('project_github_url'), array('class' => 'form-control'))); ?>

        </div>


    <?php echo e(Form::submit('Create the post!', array('class' => 'btn btn-primary'))); ?>


<?php echo e(Form::close()); ?>

</div>
</div>
<script>
        $(document).ready(function() {
            $('.summernote').summernote(
                {
                height: 200,                 // set editor height
                minHeight: null,             // set minimum height of editor
                maxHeight: null,             // set maximum height of editor                // set focus to editable area after initializing summernote
                }
            );
        });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>