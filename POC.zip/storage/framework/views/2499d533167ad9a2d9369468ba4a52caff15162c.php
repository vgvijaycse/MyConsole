<?php if(isset($_GET['q'])): ?>
<?php $__env->startSection('PageTitle', 'Search key :' .$_GET['q'] ); ?>
<?php else: ?>
<?php $__env->startSection('PageTitle', ''); ?>
<?php endif; ?>

<script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-5b3609106100445e"></script>
<?php $__env->startSection('content'); ?>

<div class="container projectGrid">
    <h3> Project List</h3>

    <div class="row">
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <div class="card col-md-4">
       <a  href="<?php echo e(URL::to('project/' . $data->id)); ?>">
    <div class="project_image">
     <img src="images/<?php echo e($data->project_image); ?>" class="img-responsive">
     </div>
  <div class="card-body">
    <h5 class="card-title"><?php echo e($data->project_name); ?></h5>
    <p class="card-text"><?php echo e($data->project_subject); ?></p>
  
  </div>
</a>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  

</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.project', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>