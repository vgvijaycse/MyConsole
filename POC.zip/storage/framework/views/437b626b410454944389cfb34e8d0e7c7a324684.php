<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e(config('app.name', 'PSSS Tech Stack')); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <script src="http://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.js"></script>
    <!-- include summernote css/js-->
    <link href="http://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.2/summernote.css" rel="stylesheet">
    <script src="http://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.2/summernote.js" defer></script>
</head>
<body>
        <?php $__env->startSection('PageNavBar'); ?>
        <nav class="navbar navbar-inverse navbar-default navbar-fixed-top">
    <div class="container-fluid ">
        <div class="navbar-header col-sm-3 col-md-3">
            <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                <?php echo e(config('app.name', 'My Console')); ?>

            </a>

        </div>
      <div class="col-sm-3 col-md-6">
        <form class="navbar-form" role="search" accept-charset="UTF-8" method="GET" action="<?php echo e(url('/search')); ?>">
        <div class="input-group">
            <input type="text" class="form-control" placeholder="Search" name="q">
            <div class="input-group-btn">
                <button class="btn btn-default" type="submit"><i class="glyphicon glyphicon-search"></i></button>
            </div>
        </div>
        </form>
    </div>
<!-- Right Side Of Navbar -->
  <ul class="nav navbar-nav navbar-right">
        <!-- Authentication Links -->
        <?php if(auth()->guard()->guest()): ?>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
            </li>
        <?php else: ?>
            <li class="nav-item dropdown">
                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                    <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                </a>

                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                       onclick="event.preventDefault();
                                     document.getElementById('logout-form').submit();">
                        <?php echo e(__('Logout')); ?>

                    </a>

                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                        <?php echo csrf_field(); ?>
                    </form>
                </div>
            </li>
        <?php endif; ?>
    </ul>
    </div>
</nav>

<div class="section section-pagebanner">
 <div class="container">
    <div class="row">
        <div class="col-md-8">
        <ol class="breadcrumb">
		<li><a  href="<?php echo e(url('/')); ?>">Home</a></li>
		<li> <?php echo $__env->yieldContent('PageTitle'); ?></li>
	</ol>  
        </div>
    </div>
</div>
</div>
<div class="container">
<div id="app">
    <main class="py-4">
        <?php echo $__env->yieldContent('content'); ?>
    </main>
 </div>
</div>
    <?php $__env->startSection('footer'); ?>
    <div class="footer">
    <div class="copyright"> COPYRIGHT © 2018. PARIPOORNA SOFTWARE SOLUTION SERVICE PVT LTD. </div>
    </div>

</body>
</html>
