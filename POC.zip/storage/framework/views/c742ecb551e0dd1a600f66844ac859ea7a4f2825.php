
        <nav class="navbar navbar-inverse inner-navbar">
           
            <ul class="nav navbar-nav">
                <li><a href="<?php echo e(URL::to('post')); ?>">View All Project</a></li>
                <li><a href="<?php echo e(URL::to('post/create')); ?>">Create a Project</a>
            </ul>
        </nav>
