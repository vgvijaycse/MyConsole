<?php $__env->startSection('PageTitle', 'Projects'); ?>
<?php $__env->startSection('content'); ?>
<div class="container">

<?php echo $__env->make('includes.subnav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <h1>All the Projects</h1>
        <!-- will be used to show any messages -->
        <?php if(Session::has('message')): ?>
            <div class="alert alert-info"><?php echo e(Session::get('message')); ?></div>
        <?php endif; ?>

        <table class="table table-striped table-bordered">
            <thead>
                <tr>
                    <td>ID</td>
                    <td>Project Name</td>
                    <td>Subject</td>

                    <td>Actions</td>
                </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($value->id); ?></td>
                    <td><?php echo e($value->project_name); ?></td>
                    <td><?php echo e($value->project_subject); ?></td>
                    <!-- we will also add show, edit, and delete buttons -->
                    <td>
                        <!-- delete the nerd (uses the destroy method DESTROY /nerds/{id} -->
                        <!-- we will add this later since its a little more complicated than the other two buttons -->
                        <!-- show the nerd (uses the show method found at GET /nerds/{id} -->
                        <a class="btn btn-small btn-success" href="<?php echo e(URL::to('project/' . $value->id)); ?>">Show </a>

                        <!-- edit this nerd (uses the edit method found at GET /nerds/{id}/edit -->
                        <a class="btn btn-small btn-info" href="<?php echo e(URL::to('project/' . $value->id . '/edit')); ?>">Edit</a>

                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>