<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Factory;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Storage;
use Input;
use Illuminate\Support\Facades\Session;
use App\Posts;
use Auth;
Use DB;
class PostController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

    
      // get all the nerds
     // $posts = Posts::all();
     
      $posts = DB::table('posts')->where('userid',  Auth::user()->id)->get();
      // load the view and pass the nerds
      return View('Post.index')
          ->with('posts', $posts);
    }



    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return View('Post.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'project_name' => 'required|unique:posts|max:255',
            'project_subject' => 'required',
            'project_description' => 'required',
            'project_github_url' => 'required',
            'project_image' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
    
        ]);

    
    
        $image = $request->file('project_image');
    
        $imagename = date('mdYHis').'.'.$request->file('project_image')->getClientOriginalExtension();
    
        $destinationPath = public_path('/images');
    
        $image->move($destinationPath, $imagename);



            // store
            $posts = new Posts;
            $posts->project_name  = Input::get('project_name');
            $posts->project_subject  = Input::get('project_subject');
            $posts->project_description = Input::get('project_description');
            $posts->project_github_url = Input::get('project_github_url');
            $posts->project_image = $imagename;
            $posts->userid =  Auth::user()->id; 
            $posts->save();

            // redirect
            Session::flash('message', 'Successfully created project!');
            return Redirect::to('post');


        // The blog post is valid...
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
