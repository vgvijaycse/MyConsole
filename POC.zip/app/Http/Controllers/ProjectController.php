<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Posts;
use DB;
class ProjectController extends Controller
{
    
    public function index(){

        return View('Project.index');

    }


    public function getproject($id){

        $data = DB::table('posts')
        ->join('users', 'users.id', '=', 'posts.userid')          
        ->select('users.*', 'posts.*')
        ->where('posts.id', $id)
        ->get();
        
        return View('Project.index')->with('dataArray',$data);

       

    }

    public function list(){

        $dataArray = DB::table('posts')
        ->join('users', 'users.id', '=', 'posts.userid')          
        ->select('users.*', 'posts.*')   
        ->get();
        

        return View('Project.list')->with('data',$dataArray);
    }
    public function search(){
      
        $dataArray = DB::table('posts')
        ->join('users', 'users.id', '=', 'posts.userid')          
        ->select('users.*', 'posts.*')
        ->Where('project_name', 'like', '%' . $_GET["q"] . '%')->get();     
        return View('Project.list')->with('data',$dataArray);
    }
}
